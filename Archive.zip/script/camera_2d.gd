extends Camera2D




# Called every frame. 'delta' is the elapsed time since the previous frame.
func _ready():
	if Global.game_loaded == false:
		await get_tree().create_timer(2).timeout
	while position.y > -6676:
		await get_tree().process_frame
		var delta = get_process_delta_time()
		position.y -= 120.0 * delta
		$ProgressBar.value = 0 - position.y + 324
		Global.camera_pos = position + Vector2(0, 324)
