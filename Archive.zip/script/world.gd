extends Node2D
var y = 600
var ammo_rng
var platform = preload("res://scene/platform.tscn")
var ball_attack = preload("res://scene/circle_obstacle.tscn")
var sine_attack = preload("res://scene/sine_obstacle.tscn")
var asteroid = preload("res://scene/asteroid.tscn")
var shootstacle = preload("res://scene/shootstacle.tscn")
var line_attack = preload("res://scene/line_obstacle.tscn")
var line_balance = preload("res://scene/line_balance.tscn")
var ammo = preload("res://scene/ammo.tscn")
var transition = preload("res://scene/transition_out.tscn")
var platform_pos
var balloon_area_middle_screen_width = 864


func _ready() -> void:
	if Global.game_loaded == false:
		await get_tree().create_timer(1.3).timeout
		var transitionclone = transition.instantiate()
		get_parent().add_child(transitionclone)
		Global.game_loaded = true
	while y > -10000:
		var new_platform = platform.instantiate()
		add_child.call_deferred(new_platform)
		platform_pos = Vector2(randi_range(60, 517), y)
		new_platform.position = platform_pos
		y -= randi_range(40,180)
		ammo_rng = randi_range(1,3)
		if ammo_rng == 1 or 2:
			var ammo_clone = ammo.instantiate()
			add_child.call_deferred(ammo_clone)
			ammo_clone.position = platform_pos - Vector2(0, 40)
	make_ball_triangle_form(-500)
	make_line_form(-4200)
	make_ball_line_form(-5000)
	make_ball_square_form(-6500)

func make_line_form(height):
	for balls in range(7):
		var line_clone = line_attack.instantiate()
		add_child.call_deferred(line_clone)
		if balls == 0:
			line_clone.position = Vector2(balloon_area_middle_screen_width, height)
		if balls == 1:
			line_clone.position = Vector2(balloon_area_middle_screen_width - 30, height)
		if balls == 2:
			line_clone.position = Vector2(balloon_area_middle_screen_width + 30, height)
		if balls == 3:
			line_clone.position = Vector2(balloon_area_middle_screen_width + 60, height)
		if balls == 4:
			line_clone.position = Vector2(balloon_area_middle_screen_width - 60, height)
		if balls == 5:
			line_clone.position = Vector2(balloon_area_middle_screen_width + 90, height)
		if balls == 6:
			line_clone.position = Vector2(balloon_area_middle_screen_width - 90, height)



func make_ball_triangle_form(height):
	for balls in range(6):
		var ball_clone = ball_attack.instantiate()
		add_child.call_deferred(ball_clone)
		if balls == 0:
			ball_clone.position = Vector2(balloon_area_middle_screen_width, height)
		if balls == 1:
			ball_clone.position = Vector2(balloon_area_middle_screen_width - 30, height + 60)
		if balls == 2:
			ball_clone.position = Vector2(balloon_area_middle_screen_width + 30, height + 60)
		if balls == 3:
			ball_clone.position = Vector2(balloon_area_middle_screen_width + 60, height + 120)
		if balls == 4:
			ball_clone.position = Vector2(balloon_area_middle_screen_width, height + 120)
		if balls == 5:
			ball_clone.position = Vector2(balloon_area_middle_screen_width - 60, height + 120)

func make_ball_line_form(height):
	for balls in range(8):
		var ball_clone = ball_attack.instantiate()
		var balance = line_balance.instantiate()
		if balls == 7:
			add_child.call_deferred(balance)
		else:
			add_child.call_deferred(ball_clone)
		if balls == 0:
			ball_clone.position = Vector2(balloon_area_middle_screen_width, height)
		if balls == 1:
			ball_clone.position = Vector2(balloon_area_middle_screen_width - 40, height)
		if balls == 2:
			ball_clone.position = Vector2(balloon_area_middle_screen_width + 40, height)
		if balls == 3:
			ball_clone.position = Vector2(balloon_area_middle_screen_width + 80, height)
		if balls == 4:
			ball_clone.position = Vector2(balloon_area_middle_screen_width - 80, height)
		if balls == 5:
			ball_clone.position = Vector2(balloon_area_middle_screen_width + 120, height)
		if balls == 6:
			ball_clone.position = Vector2(balloon_area_middle_screen_width - 120, height)
		if balls == 7:
			balance.position = Vector2(balloon_area_middle_screen_width, height + 40)

func make_ball_square_form(height):
	for balls in range(14):
		var ball_clone = ball_attack.instantiate()
		add_child.call_deferred(ball_clone)
		if balls == 0:
			ball_clone.position = Vector2(balloon_area_middle_screen_width, height)
		if balls == 1:
			ball_clone.position = Vector2(balloon_area_middle_screen_width - 60, height)
		if balls == 2:
			ball_clone.position = Vector2(balloon_area_middle_screen_width + 60, height)
		if balls == 3:
			ball_clone.position = Vector2(balloon_area_middle_screen_width + 120, height)
		if balls == 4:
			ball_clone.position = Vector2(balloon_area_middle_screen_width - 120, height)
		if balls == 5:
			ball_clone.position = Vector2(balloon_area_middle_screen_width + 180, height)
		if balls == 6:
			ball_clone.position = Vector2(balloon_area_middle_screen_width - 180, height)
		if balls == 7:
			ball_clone.position = Vector2(balloon_area_middle_screen_width, height + 60)
		if balls == 8:
			ball_clone.position = Vector2(balloon_area_middle_screen_width - 60, height + 60)
		if balls == 9:
			ball_clone.position = Vector2(balloon_area_middle_screen_width + 60, height + 60)
		if balls == 10:
			ball_clone.position = Vector2(balloon_area_middle_screen_width + 120, height + 60)
		if balls == 11:
			ball_clone.position = Vector2(balloon_area_middle_screen_width - 120, height + 60)
		if balls == 12:
			ball_clone.position = Vector2(balloon_area_middle_screen_width + 180, height + 60)
		if balls == 13:
			ball_clone.position = Vector2(balloon_area_middle_screen_width - 180, height + 60)

# Sine Wave Attack thingy
func _on_timer_timeout() -> void:
	var sine_clone = sine_attack.instantiate()
	add_child.call_deferred(sine_clone)


func _on_asteroid_timeout() -> void:
	var asteroid_clone_left = asteroid.instantiate()
	add_child.call_deferred(asteroid_clone_left)
	asteroid_clone_left.position.y = -1900
	asteroid_clone_left.position.x = 1154
	asteroid_clone_left.rotation_degrees = 170
	asteroid_clone_left.get_node("Icon").flip_v = true
	var asteroid_clone_right = asteroid.instantiate()
	add_child.call_deferred(asteroid_clone_right)
	asteroid_clone_right.position.y = -1900
	asteroid_clone_right.position.x = 0
	asteroid_clone_right.rotation_degrees = 10


func _on_shootstacle_timeout() -> void:
	for i in 5:
		var shootstacleclone = shootstacle.instantiate()
		add_child.call_deferred(shootstacleclone)
		shootstacleclone.position.y = -2700
		await get_tree().create_timer(2).timeout


func _on_shootstacle_2_timeout() -> void:
	for i in 10:
		var shootstacleclone = shootstacle.instantiate()
		add_child.call_deferred(shootstacleclone)
		shootstacleclone.position.y = -2700
		await get_tree().create_timer(1).timeout
