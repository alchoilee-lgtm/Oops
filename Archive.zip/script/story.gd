extends Node2D
var transition = preload("res://scene/transition.tscn")
var transition_out = preload("res://scene/transition_out.tscn")
var scene_1 = preload("res://scene/frame_1.tscn")
var scene_2 = preload("res://scene/frame_2.tscn")
var scene_3 = preload("res://scene/frame_3.tscn")

func _ready():
	var transitionclone = transition_out.instantiate()
	get_parent().add_child(transitionclone)
	var clone_1 = scene_1.instantiate()
	var clone_2 = scene_2.instantiate()
	var clone_3 = scene_3.instantiate()
	add_child(clone_1)
	add_child(clone_2)
	add_child(clone_3)


func _on_timer_timeout() -> void:
	var transitionclone = transition.instantiate()
	get_parent().add_child(transitionclone)
	await get_tree().create_timer(2).timeout
	get_tree().change_scene_to_file("res://scene/world.tscn")
