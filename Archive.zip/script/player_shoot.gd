extends Node2D

func _ready():
	$GPUParticles2D.emitting = true
	global_position = Global.player_pos
	look_at(get_global_mouse_position())
	$GPUParticles2D.rotation = rotation
