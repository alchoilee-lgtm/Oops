extends RigidBody2D

signal die
var distance_to_mouse
var touched_player_after_launch = 7

func _ready():
	can_sleep = false

func _integrate_forces(state: PhysicsDirectBodyState2D) -> void:
	distance_to_mouse = (get_global_mouse_position() - global_position)
	
	
	if Input.is_action_pressed("click"):
		state.linear_velocity = distance_to_mouse * 15
	
	if Input.is_action_just_released("click"):
		touched_player_after_launch = 0
		state.linear_velocity = Vector2.ZERO
	


func _on_area_2d_area_entered(area: Area2D) -> void:
	if touched_player_after_launch < 1:
		touched_player_after_launch += 1
	elif touched_player_after_launch == 1:
		queue_free()
		die.emit()
