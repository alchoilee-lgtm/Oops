extends RigidBody2D

var parts = preload("res://scene/bombings.tscn")
var pick_side = randi_range(1, 2)

var fling_force = 1600
func _ready() -> void:
	position.y = Global.balloon_pos.y
	freeze = false
	can_sleep = false
	print("OMG")
	if pick_side == 1:
		position.x = 1154
		fling_left()
	else:
		position.x = 0
		fling_right()

func fling_left() -> void:
	linear_velocity = Vector2.ZERO
	var force = ((Vector2.UP * 0.6) + Vector2.LEFT * 0.2).normalized()
	apply_central_impulse(force * (fling_force - 300))

func fling_right() -> void:
	linear_velocity = Vector2.ZERO
	var force = ((Vector2.UP * 4) + Vector2.RIGHT * 5).normalized()
	apply_central_impulse(force * fling_force)


func _on_area_2d_area_entered(area: Area2D) -> void:
	var bomb = parts.instantiate()
	get_parent().add_child(bomb)
	bomb.position = global_position
	queue_free()
