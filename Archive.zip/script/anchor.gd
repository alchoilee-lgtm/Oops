extends CharacterBody2D

func _process(delta: float) -> void:
	global_position = Global.player_pos

func _on_box_die() -> void:
	queue_free()
