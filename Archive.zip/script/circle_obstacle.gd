extends RigidBody2D

func _ready():
	freeze = true


func _on_area_2d_area_entered(area: Area2D) -> void:
	self.call_deferred("set_freeze_enabled", false)
