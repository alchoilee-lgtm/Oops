extends Node
var player_pos
var balloon_pos
var camera_pos = Vector2.ZERO
var game_loaded = false
var death_cause = 0
