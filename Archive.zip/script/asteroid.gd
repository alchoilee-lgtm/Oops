extends RigidBody2D


var pick_side = randi_range(1, 2)

func _ready():
	can_sleep = false
	freeze = true


func _physics_process(delta: float) -> void:
	global_position += transform.x * 200 * delta



func _on_area_2d_area_entered(area: Area2D) -> void:
	self.call_deferred("set_freeze_enabled", false)


func _on_visible_on_screen_notifier_2d_screen_exited() -> void:
	queue_free()
