extends RigidBody2D
var time = 0.0
var new_x = 1154
func _ready():
	freeze = true
	position.x = 1154
	position.y = -1000

func _physics_process(delta: float) -> void:
	if freeze:
		time += 1.0 * delta
		var sine = sin(time)
		new_x -= 100.0 * delta
		global_position = Vector2(new_x, (sine * 100) - 1000)



func _on_area_2d_area_entered(area: Area2D) -> void:
	self.call_deferred("set_freeze_enabled", false)


func _on_visible_on_screen_notifier_2d_screen_exited() -> void:
	queue_free()
 
