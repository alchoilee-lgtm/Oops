extends Sprite2D

func _ready():
	modulate.a = 0



func _on_menu_start() -> void:
	for i in range(10):
		modulate.a += 0.1
		await get_tree().create_timer(0.05).timeout
