extends Sprite2D


func _ready():
	position = Vector2(575, 986)
	for i in range(50):
		position.y = lerp(position.y, 321.0, 0.1)
		await get_tree().create_timer(0.01).timeout
	await get_tree().create_timer(2.5).timeout
	queue_free()
