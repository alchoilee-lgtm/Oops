extends Sprite2D

func _ready():
	position = Vector2(575, 321)
	for i in range(50):
		position.y = lerp(position.y, 986.0, 0.1)
		await get_tree().create_timer(0.01).timeout
	queue_free()
